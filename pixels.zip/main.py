from random import *
from pygame import *
from pygame.gfxdraw import *
from keyboard import *
from module import Screen

init()

window = None
win_width = 600
win_heigth = 600
clock = time.Clock()
fps = 240

def main():
    global window, win_width, win_heigth, clock, fps
    running = True
    window = display.set_mode((win_width, win_heigth))
    white = False
    count = 0
    screen = Screen(window, win_width, win_heigth, 0, 255, white)
    display.set_caption("PIXELS")
    while running:
        for e in event.get():
            if e.type == QUIT:
                running = False
        if is_pressed("q") or is_pressed("escape"):
            running = False
        if is_pressed("s"):
            screen = Screen(window, win_width, win_heigth, 0, 255, white)
        if is_pressed("w"):
            white = False
        if is_pressed("e"):
            white = True
        if is_pressed("m"):
            inp = input("Folder Name: ")
            if "kratos" in inp:
                kratos = image.load("kratos.jfif")
                inpt = inp.split("kratos")
                image.save(kratos, f"{inp}/kratos{randrange(100)}.png")
            else:
                image.save(window, f"{inp}/{randrange(1000)}.png")
        screen.display()

        display.flip()
        clock.tick(fps)

if __name__ == "__main__":
    main()