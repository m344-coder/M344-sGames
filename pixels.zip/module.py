from random import *
from pygame import *
from pygame.gfxdraw import *

class Screen(object):
    def __init__(self, surface, width, height, min, max, white):
        self.min = min
        self.max = max
        self.width = width
        self.height = height
        self.surface = surface
        self.white = white
    def display(self):
        for x in range(self.width // 10):
            for y in range(self.height // 10):
                if self.white == False:
                    box(self.surface, Rect(x * 10, y*10, 10, 10), (randrange(self.min, self.max), randrange(self.min, self.max), randrange(self.min, self.max)))
                elif self.white == True:
                    box(self.surface, Rect(x*10, y*10, 10, 10), choice([(0,0,0), (255, 255, 255)]))